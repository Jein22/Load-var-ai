import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("RefAI")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text("مرحبًا بك في تطبيق تحليل التسلل")
                    .font(.headline)

                NavigationLink(destination: Text("واجهة التحليل قادمة قريبًا")) {
                    Text("ابدأ التحليل")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }

                Button("أرسل إشعار تسلل") {
                    WatchSessionManager.shared.sendOffsideStatus(message: "🚩 تسلل تم اكتشافه!")
                }
                .foregroundColor(.white)
                .padding()
                .background(Color.red)
                .cornerRadius(10)
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
