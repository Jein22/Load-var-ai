import Foundation
import WatchConnectivity

class WatchSessionManager: NSObject, WCSessionDelegate, ObservableObject {
    static let shared = WatchSessionManager()

    private override init() {
        super.init()
    }

    func activateSession() {
        if WCSession.isSupported() {
            WCSession.default.delegate = self
            WCSession.default.activate()
        }
    }

    func sendOffsideStatus(message: String) {
        if WCSession.default.isReachable {
            WCSession.default.sendMessage(["status": message], replyHandler: nil, errorHandler: nil)
        } else {
            print("Apple Watch is not reachable.")
        }
    }

    // MARK: - WCSessionDelegate Methods (إلزامية في بعض الحالات)

    func sessionDidBecomeInactive(_ session: WCSession) {
        // Optional - required if your app supports multiple sessions
    }

    func sessionDidDeactivate(_ session: WCSession) {
        // Optional - required if your app supports multiple sessions
    }

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        // This is required
        if let error = error {
            print("WC Session activation failed with error: \(error.localizedDescription)")
        } else {
            print("WC Session activated with state: \(activationState.rawValue)")
        }
    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        print("Received message from Watch: \(message)")
    }
}
