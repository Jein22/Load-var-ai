import SwiftUI

@main
struct RefAIApp: App {
    
    init() {
        WatchSessionManager.shared.activateSession()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
