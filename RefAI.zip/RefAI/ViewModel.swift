import Foundation
import WatchConnectivity

class OffsideViewModel: NSObject, ObservableObject, WCSessionDelegate {
    @Published var offsideStatus: String = "جارٍ التحقق..."

    override init() {
        super.init()
        activateSession()
        fetchOffsideStatus()
    }

    private func activateSession() {
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
    }

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        print("Watch session activated with state: \(activationState.rawValue)")
    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        if let status = message["offside"] as? String {
            DispatchQueue.main.async {
                self.offsideStatus = status
            }
        }
    }

    // لو كنت تبغى تدعم الاتصال بين الأجهزة (iOS <-> Watch)
    func sessionDidBecomeInactive(_ session: WCSession) {}
    func sessionDidDeactivate(_ session: WCSession) {}
    func sessionWatchStateDidChange(_ session: WCSession) {}

    func fetchOffsideStatus() {
        guard let url = URL(string: "http://localhost:5000/status") else { return }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data,
               let result = try? JSONDecoder().decode(OffsideResponse.self, from: data) {
                DispatchQueue.main.async {
                    self.offsideStatus = result.status
                    self.sendToWatch(message: result.status)
                }
            }
        }.resume()
    }

    func sendToWatch(message: String) {
        if WCSession.default.isReachable {
            WCSession.default.sendMessage(["offside": message], replyHandler: nil, errorHandler: nil)
        }
    }
}

struct OffsideResponse: Codable {
    let status: String
}
