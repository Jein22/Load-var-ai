import Foundation
import WatchConnectivity

class WatchReceiver: NSObject, ObservableObject, WCSessionDelegate {
    static let shared = WatchReceiver()
    @Published var status: String = "في الانتظار..."
    var onReceive: ((String) -> Void)?

    private override init() {
        super.init()
        if WCSession.isSupported() {
            WCSession.default.delegate = self
            WCSession.default.activate()
        }
    }

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        if let error = error {
            print("حدث خطأ عند تفعيل الجلسة: \(error.localizedDescription)")
        } else {
            print("تم تفعيل الجلسة بنجاح: \(activationState.rawValue)")
        }
    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        DispatchQueue.main.async {
            if let msg = message["offside"] as? String {
                self.status = msg
                self.onReceive?(msg)
            }
        }
    }
}
