import SwiftUI

struct WatchContentView: View {
    @ObservedObject var watchManager = WatchConnectivityManager.shared

    var body: some View {
        VStack {
            Text("RefAI Watch")
                .font(.headline)
            Text(watchManager.receivedMessage)
                .padding()
        }
    }
}

