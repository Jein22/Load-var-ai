import WatchConnectivity
import WatchKit

class WatchDelegate: NSObject, WKExtensionDelegate, WCSessionDelegate {

    override init() {
        super.init()
        activateSession()
    }

    func activateSession() {
        if WCSession.isSupported() {
            WCSession.default.delegate = self
            WCSession.default.activate()
        }
    }

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        print("Watch session activated")
    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        if let status = message["status"] as? String {
            print("تسلمت من iOS: \(status)")
            // تقدر هنا تعرض إشعار أو تحدث الواجهة
        }
    }
}
