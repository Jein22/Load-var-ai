import SwiftUI

struct WatchContentView: View {
    @ObservedObject var receiver = WatchReceiver.shared

    var body: some View {
        VStack(spacing: 10) {
            Text("RefAI - Apple Watch")
                .font(.headline)
            Text(receiver.status)
                .multilineTextAlignment(.center)
                .padding()
        }
        .onAppear {
            WatchReceiver.shared.onReceive = { newMessage in
                receiver.status = newMessage
            }
        }
    }
}
