import SwiftUI
import WatchKit

@main
struct RefAIWatchApp: App {
    @WKExtensionDelegateAdaptor(WatchDelegate.self) var delegate
    
    var body: some Scene {
        WindowGroup {
            WatchContentView()
        }
    }
    class WatchDelegate: NSObject, WKExtensionDelegate {
        func applicationDidFinishLaunching() {
            // هنا تقدر تضيف أي كود تهيئة عند تشغيل الساعة
            print("Watch App Launched")
        }
    }

}


